package examples.bc.plugins.account;

import aQute.bnd.annotation.component.Component;
import gw.bc.account.entity.Account;
import gw.bc.account.typekey.AccountEvaluation;
import gw.plugin.account.IAccountEvaluationCalculator;

import java.util.Date;

/**
 * This is an example implementation for the IAccountEvaluationCalculator plugin interface.  This plugin computes
 * an evaluation rating for an account (poor, fair, good, etc) based on certain criteria.  This plugin implementation
 * can be modified / customized as needed to meet business requirements of a particular customer
 *
 *
 *   WARNING:  Out of the box we do not use this file.
 *     Instead we use the gosu plugin gw.plugin.account.impl.AccountEvaluationCalculator
 *
 *
 */
@Component
public class AccountEvaluationCalculator implements IAccountEvaluationCalculator {

  // Time period in days over which system should run queries for various pieces of information we will use in
  // determining the account evaluation rating (for example: how many delinquencies on the account in the last 365 days)
  private static final int NumberOfDaysForMetricsSearch = 365;

  // Thresholds for number of delinquencies on the account
  private static final int MaxDelinquenciesForExcellent = 1;
  private static final int MaxDelinquenciesForGood = 2;
  private static final int MaxDelinquenciesForAcceptable = 4;
  private static final int MaxDelinquenciesForMarginal = 6;

  // Thresholds for number of occurrences of pejorative payment reversals on the account
  private static final int MaxPaymentReversalsForExcellent  = 0;
  private static final int MaxPaymentReversalsForGood       = 0;
  private static final int MaxPaymentReversalsForAcceptable = 1;
  private static final int MaxPaymentReversalsForMarginal   = 2;

  // Thresholds for number of policy cancellations on the account
  private static final int MaxPolicyCancellationsForExcellent = 0;
  private static final int MaxPolicyCancellationsForGood = 1;
  private static final int MaxPolicyCancellationsForAcceptable = 2;
  private static final int MaxPolicyCancellationsForMarginal = 3;

  // We will give an account an evaluation of New Account if it is less than a year old
  private static final long MaxAgeOfNewAccountInMilliseconds = 365L * 24L * 60L * 60L * 1000L;

  @Override
  public AccountEvaluation calculateEvaluation(Account account,
                                               Date currentTime,
                                               int numDelinquencies,
                                               int numDelinquenciesPastGracePeriod,
                                               int numPaymentReversals,
                                               int numPolicyCancellations) {

    if (currentTime.getTime() - account.getCreateTime().getTime() <= MaxAgeOfNewAccountInMilliseconds) {
      return  AccountEvaluation.getTypeKey("NEWACCOUNT");
    }
    else if (numDelinquencies <= MaxDelinquenciesForExcellent &&
             numPaymentReversals <= MaxPaymentReversalsForExcellent &&
             numPolicyCancellations <= MaxPolicyCancellationsForExcellent) {
      return AccountEvaluation.getTypeKey("EXCELLENT");
    }
    else if (numDelinquencies <= MaxDelinquenciesForGood &&
             numPaymentReversals <= MaxPaymentReversalsForGood &&
             numPolicyCancellations <= MaxPolicyCancellationsForGood) {
      return AccountEvaluation.getTypeKey("GOOD");
    }
    else if (numDelinquencies <= MaxDelinquenciesForAcceptable &&
             numPaymentReversals <= MaxPaymentReversalsForAcceptable &&
             numPolicyCancellations <= MaxPolicyCancellationsForAcceptable) {
      return AccountEvaluation.getTypeKey("ACCEPTABLE");
    }
    else if (numDelinquencies <= MaxDelinquenciesForMarginal &&
             numPaymentReversals <= MaxPaymentReversalsForMarginal &&
             numPolicyCancellations <= MaxPolicyCancellationsForMarginal) {
      return AccountEvaluation.getTypeKey("MARGINAL");
    }
    else {
      return AccountEvaluation.getTypeKey("POOR");
    }
  }

  @Override
  public boolean countUniqueDelinquenciesAndCancellationsOnly() {
    return true;
  }

  @Override
  public int getMetricsQueryTimePeriod() {
    return NumberOfDaysForMetricsSearch;
  }
}
