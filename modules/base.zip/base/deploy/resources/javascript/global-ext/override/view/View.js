Ext.define('Gw.override.view.view', {
  override: 'Ext.view.View',

  /**
   * Allow text to be copied and pasted into clipboard
   */
  enableTextSelection: true

});
